package com.internship.waterwells;

import java.io.File;
import java.io.IOException;

import javax.swing.JPanel;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class Panel extends JPanel{
	private boolean running;
	
	private boolean dataFound;
	
	String rand;
	String sheetName;
	int rows;
	int columns;
	int sheetNum;
	int numWB = 4;
	String mean;
	
	private int rowNum;
	private int blanks;
	int columnNum;
	
	private float total;
	
	String data;
	public static String string;
	public String rowInfo;
	public float rowData;
	
	private boolean passed;
	
	File dataset1;
	File dataset2;
	File dataset3;
	File dataset4;
	
	Workbook wb;
	Workbook wb2;
	Workbook wb3;
	Workbook wb4;
	
	String newMean;

	public Panel() throws BiffException, IOException{
		dataFound = false;
		passed = false;
		
		dataset1 = new File("res/dataset1.xls");
		dataset2 = new File("res/dataset2.xls");
		dataset3 = new File("res/dataset3.xls");
		dataset4 = new File("res/dataset4.xls");
		
		wb = Workbook.getWorkbook(dataset2);
		System.out.println("workbook 2 loaded");
		
		rand = wb.getSheet(2).getCell(0, 14).getContents();
		sheetName = wb.getSheet(2).getName();
		rows = wb.getSheet(2).getRows();
		columns = wb.getSheet(2).getColumns();
		sheetNum = wb.getSheets().length;
		
		string = "start";
		
		running = true;
		
		while(running){
			update();
		}
	}
	private void update(){
		//checks if input equals a sheet name
		for(int f = 0; f < wb.getNumberOfSheets() - 1; f++){
			sheetName = wb.getSheet(f).getName();
			
			if(string.equals(sheetName)){
				System.out.println("data found");
				sheetNum = f;
				dataFound = true;
			}	
		}
		if(dataFound == true){
			for(int k = 0; k < wb.getSheet(sheetNum).getRows() - 1; k++){
				for(int j = 0; j < wb.getSheet(sheetNum).getColumns() - 1; j++){
					data = wb.getSheet(sheetNum).getCell(j, k).getContents();
					if(data.equals("Completed Depth 'm'")){
						columnNum = k;
						rowNum = j;
						
						for(int y = 0; y < wb.getSheet(sheetNum).getColumns(); y++){
							//print out data
							rowInfo = wb.getSheet(sheetNum).getCell(y, columnNum).getContents();
							System.out.println("" + rowInfo);
							
							//find total of all data
							if(y >= 0){
								try{
									rowData = Float.valueOf(rowInfo);
									total = total + rowData;
								}catch(Exception e){
									System.out.println("DATA NOT INT");
									blanks++;
								}
							}
						}
						
						columnNum = wb.getSheet(sheetNum).getColumns() - blanks - 1;
						
						finalOutput();
						string = "fwrgergjnr";
						dataFound = false;
						blanks = 0;
						total = 0;
					}
				}
			}
		}
	}
	private void finalOutput(){
		System.out.println("output: " + string);
		System.out.println("TOTAL: " + total);
		System.out.println("MEAN: " + total / columnNum);
		System.out.println("___________________________");
	}
}
