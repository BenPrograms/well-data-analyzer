package com.internship.waterwells;

import java.awt.Button;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JPanel;

import jxl.Workbook;
import jxl.read.biff.BiffException;

public class Main {
	public static void main(String[] args) throws Exception{
		JFrame frame = new JFrame();
		JPanel panel = new JPanel();
		TextField field = new TextField();
		Button button = new Button();
		
		button.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent arg0) {
		    	Panel.string = field.getText();
		    }
		});
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("water-well-data-analyzer");
		
		panel.setLayout(new GridLayout(4, 4));
		panel.setMaximumSize(new Dimension(600, 300));

		field.setLocation(200, 40);
		button.setLabel("submit");
		button.setLocation(100, 40);
		frame.setSize(600, 300);
		panel.add(field);
		panel.add(button);
		frame.add(panel);
		
		button.setVisible(true);
		field.setVisible(true);
		frame.setVisible(true);
		frame.setResizable(false);
		frame.setContentPane(new Panel());
	}
}
